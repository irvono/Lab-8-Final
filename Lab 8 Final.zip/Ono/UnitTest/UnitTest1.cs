﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using Ono.Controllers;
using Ono.Models;

namespace Ono.UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        const string ONER1_NAME = "Irvin Vargas", ONER2_NAME = "Jacob Pratt";
        const string PHOTO1_NAME = "Fire Up", PHOTO2_TITLE = "Brown Gold";
        [TestMethod]
        public void EditInfo_Index_Test()
        {
            // arrange
            List<Oner> oners = new List<Oner>();
            List<Book> books = new List<Book>();
        }
    }
}
