﻿using Ono.DAL;
using Ono.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ono.Controllers
{
    public class EditInfoController : Controller
    {
        IUnitOfWork uow;

        public EditInfoController()
        {
            uow = new UnitOfWork();
        }

        public EditInfoController(IUnitOfWork fakeUow)
        {
            uow = fakeUow;
        }

        // GET: EditInfo
        // This method illustrates using a view model to pass information
        // This example is a bit contrived since we can use List<Author> to do the same thing.
        public ActionResult Index()
        {
            var oners = uow.OnerRepo.Get(includeProperties: "Photos");

            // Just copying from the entity models to the view model
            var vmList = new List<OnerViewModel>();
            foreach (Oner o in oners)
            {
                foreach (Photo p in o.Photos)
                {
                    vmList.Add(new OnerViewModel()
                    {
                        LastName = o.LastName,
                        FirstName = o.FirstName,
                        Photo = new PhotoViewModel() { Name = p.Name }
                    });
                }
            }

            return View(vmList);
        }

        // GET: EditInfo
        // This method shows that we can actually use one of our entity models to pass the same information 
        // that we passed using the view model in the index method.
        public ActionResult List()
        {
            var oners = uow.OnerRepo.Get(includeProperties: "Photos");
            return View(oners);
        }

        // GET: BooksCrud/Create
        public ActionResult Create()
        {
            var oners = uow.OnerRepo.Get();

            var onerNames = new List<string>();
            foreach (Oner o in oners)
                onerNames.Add(o.FirstName);
            ViewBag.onerList = new SelectList(onerNames);

            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "LastName,FirstName")] OnerViewModel onerVm, string oners)
        {
            if (ModelState.IsValid)
            {
                Oner oner = new Oner();
                oner.FirstName = onerVm.FirstName;
                oner.LastName = onerVm.LastName;
                

                var anOner = uow.OnerRepo.Get(o => o.LastName == oner.ToString()).FirstOrDefault();

                oner.ID = anOner.ID;
                // TODO: Get author object from db by name
                uow.OnerRepo.Insert(oner);
                uow.Save();
                return RedirectToAction("Index");
            }

            return View(onerVm);
        }
    }
}