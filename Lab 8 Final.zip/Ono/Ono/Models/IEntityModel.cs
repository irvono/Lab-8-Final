﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ono.Models
{
    public interface IEntityModel
    {
        int ID { get; set; }
    }
}
