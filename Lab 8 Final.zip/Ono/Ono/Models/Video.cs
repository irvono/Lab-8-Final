﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Ono.Models
{
    public class Video : IEntityModel
    {
     
        public int ID { get; set; }
        public string Title { get; set; }
        public int GenreID { get; set; }
        public int OnerID { get; set; }

        //The 1 side of the relationship
        //public virtual User User { get; set; }
        //public virtual Genre Genre { get; set; }

    }
}
