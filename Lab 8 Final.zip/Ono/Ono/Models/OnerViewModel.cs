﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ono.Models
{
    public class OnerViewModel
    {
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public PhotoViewModel Photo { get; set; }
    }

    public class PhotoViewModel
    {
        public string Name { get; set; }
    }
}
