﻿using Ono.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ono.DAL
{
    public class FakeUnitOfWork : IUnitOfWork
    {
        private IOnerRepository<Oner> onerRepo;
        private IOnerRepository<Album> albumRepo;
        private IOnerRepository<Photo> photoRepo;
        private IOnerRepository<Event> eventRepo;
        private IOnerRepository<Genre> genreRepo;
        private IOnerRepository<Video> videoRepo;

        private List<Oner> oners;
        private List<Album> albums;
        private List<Photo> photos;
        private List<Event> events;
        private List<Genre> genres;
        private List<Video> videos;

        public FakeUnitOfWork(List<Oner> o = null, List<Album> a = null, List<Photo> p = null, List<Event> e = null, List<Genre> g = null, List<Video> v = null)
        {
            if (o == null)
                oners = new List<Oner>();
            else
                oners = o;

            if (a == null)
                albums = new List<Album>();
            else
                albums = a;
            if (p == null)
                photos = new List<Photo>();
            else
                photos = p;
            if (e == null)
                events = new List<Event>();
            else
                events = e;
            if (g == null)
                genres = new List<Genre>();
            else
                genres = g;
            if (v == null)
                videos = new List<Video>();
            else
                videos = v;
        }

        public IOnerRepository<Models.Oner> OnerRepo
        {
            get
            {
                if (this.onerRepo == null)
                {
                    this.onerRepo = new FakeOnerRepository<Oner>(oners);
                }
                return onerRepo;
            }
        }

        public IOnerRepository<Models.Album> AlbumRepo
        {
            get
            {
                if (this.albumRepo == null)
                {
                    this.albumRepo = new FakeOnerRepository<Album>(albums);
                }
                return albumRepo;
            }
        }

        public IOnerRepository<Models.Photo> PhotoRepo
        {
            get
            {
                if (this.photoRepo == null)
                {
                    this.photoRepo = new FakeOnerRepository<Photo>(photos);
                }
                return photoRepo;
            }
        }

        public IOnerRepository<Models.Event> EventRepo
        {
            get
            {
                if (this.eventRepo == null)
                {
                    this.eventRepo = new FakeOnerRepository<Event>(events);
                }
                return eventRepo;
            }
        }

        public IOnerRepository<Models.Genre> GenreRepo
        {
            get
            {
                if (this.genreRepo == null)
                {
                    this.genreRepo = new FakeOnerRepository<Genre>(genres);
                }
                return genreRepo;
            }
        }

        public IOnerRepository<Models.Video> VideoRepo
        {
            get
            {
                if (this.videoRepo == null)
                {
                    this.videoRepo = new FakeOnerRepository<Video>(videos);
                }
                return videoRepo;
            }
        }

        public void Save()
        {
            // Nothing to do here
        }

        public void Dispose()
        {
            // Nothing to do here
        }
    }
}
