﻿using Ono.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ono.DAL
{
       public interface IUnitOfWork : IDisposable
        {
            IOnerRepository<Oner> OnerRepo { get; }
            IOnerRepository<Album> AlbumRepo { get; }
            IOnerRepository<Photo> PhotoRepo { get; }
            IOnerRepository<Event> EventRepo { get; }
            IOnerRepository<Genre> GenreRepo { get; }
            IOnerRepository<Video> VideoRepo { get; }

            void Save();
        }
}
